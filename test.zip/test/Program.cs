﻿using System;
using Newtonsoft.Json;
namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            string result = JsonConvert.SerializeObject(HelperProvider.GetToken(27));

            Console.WriteLine("the result is :" + result);
        }
    }
}
